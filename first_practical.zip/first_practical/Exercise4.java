package first_practical;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise4 {

public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
	WebDriver driver=new FirefoxDriver();
	driver.get("https://demo.guru99.com/test/selenium-xpath.html");
	
	List<WebElement> in=driver.findElements(By.xpath("//*[@type='text']//following::input"));
	for (int i=0; i<in.size();i++){
	      System.out.println("Elements are:" + in.get(i).getAttribute("name"));
	}
	
	List<WebElement> ancestor=driver.findElements(By.xpath("//*[text()='Enterprise Testing']//ancestor::div"));
	for (int i=0; i<ancestor.size();i++){
	      System.out.println("Ancestor are:" + ancestor.get(i).getAttribute("class"));
	}
	
	WebElement preceding=driver.findElement(By.xpath("//*[@type='submit']//preceding::input[2]"));
	System.out.println("Preceding Element is: "+preceding.getAttribute("name"));
	
	WebElement sibling=driver.findElement(By.xpath("//*[@type='submit']//following-sibling::input"));
	System.out.println("Sibling is: "+sibling.getAttribute("name"));
	
	WebElement parent=driver.findElement(By.xpath("//*[@type='submit']//parent::td"));
	System.out.println("Parent is: "+parent.getText());
	
	List<WebElement> descendant=driver.findElements(By.xpath("//*[@name='frmLogin']//descendant::input"));
	for (int i=0; i<descendant.size();i++){
	      System.out.println("Descendant are:" + descendant.get(i).getAttribute("name"));
	}
}
}

package first_practical;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class HandlingPopup {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();//create webdriver instance
		driver.get("file:///E:/Flight_Reservation/flight_reservation.html");
		
		String mainWindow=driver.getWindowHandle();//retrive the unique reservation window
		System.out.println("Main Window Handle "+mainWindow);
		System.out.println("Title of main window is "+driver.getTitle());
		WebElement hotellink = driver.findElement(By.linkText("Hotels"));
		hotellink.click();
		
		Set<String> handles = driver.getWindowHandles();
		for(String windowHandle: handles) {
			if(!windowHandle.equals(mainWindow)) {
				driver.switchTo().window(windowHandle);
				System.out.println("Title of child window is "+driver.getTitle());
				WebElement heading1 = driver.findElement(By.id("sampleHeading"));
				System.out.println("heading inside child window is "+heading1.getText());
				
				Thread.sleep(3000);
				driver.close();
				
			}
		}
		
		driver.switchTo().window(mainWindow);
		System.out.println("Title of Main Window" +driver.getTitle());
		
	}

}

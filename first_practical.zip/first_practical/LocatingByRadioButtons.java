package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingByRadioButtons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();//create webdriver instance
		driver.get("https://demo.guru99.com/test/radio.html");
		
		WebElement radiobtn1=driver.findElement(By.id("vfb-7-1"));
		radiobtn1.click();
		
		WebElement radiobtn2=driver.findElement(By.id("vfb-7-2"));
		radiobtn2.click();
		
		WebElement radiobtn3=driver.findElement(By.id("vfb-7-3"));
		radiobtn3.click();
		
		WebElement checkbox1=driver.findElement(By.id("vfb-6-0"));
		checkbox1.click();
		
		WebElement checkbox2=driver.findElement(By.id("vfb-6-1"));
		
		checkbox2.click();
		
		checkbox1.click();
		
		
	}

}

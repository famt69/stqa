package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class MoveByOffset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/HTML%20file%20for%20testing/Selectable.html");
		
		WebElement seven = driver.findElement(By.name("seven"));
		System.out.println("X coordinate: "+seven.getLocation().x + "Y coodinate:  "+seven.getLocation().y);
		
		Actions builder = new Actions(driver);//Instantiated action class object
		
		builder.moveByOffset(seven.getLocation().x+1,seven.getLocation().y+1).click();
		
		builder.perform();
		
		
		
		
	}

}

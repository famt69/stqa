package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class MoveToElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/HTML%20file%20for%20testing/Sortable.html");
		
		//locate tile 3
		WebElement three = driver.findElement(By.name("three"));
		Actions builder =new Actions(driver);
		
		//locate tile 5
		WebElement five = driver.findElement(By.name("five"));
		
		builder.moveToElement(three).clickAndHold().release(five).perform();
		
	}

}

package first_practical;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropbox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://output.jsbin.com/osebed/2");
		
		Select fruits = new Select(driver.findElement(By.id("fruits")));
		fruits.selectByVisibleText("Orange");
		System.out.println(fruits.getFirstSelectedOption().getText());
		
		fruits.selectByValue("apple");
		fruits.selectByIndex(0);
		Thread.sleep(2000);
		
		//fruits.deselectByIndex(0);
		//Thread.sleep(2000);
		
		//fruits.deselectByVisibleText("Orange");
		//Thread.sleep(2000);.
		
		//fruits.deselectByValue("apple");
		//Thread.sleep(2000);
		
		List<WebElement> selected_items=fruits.getAllSelectedOptions();
		for(int i=0;i<selected_items.size();i++) {
			System.out.println(selected_items.get(i).getText());
			
		}
		
		System.out.println(fruits.isMultiple());
		
		
		
		
	}

}

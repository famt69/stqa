package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CssSelectorByParentchild {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
				WebDriver driver = new FirefoxDriver();//create webdriver instance
				driver.get("https://demoqa.com/select-menu");
				
				WebElement color = driver.findElement(By.cssSelector("select#oldSelectMenu>option:nth-of-type(4)"));
				color.click();
	}

}

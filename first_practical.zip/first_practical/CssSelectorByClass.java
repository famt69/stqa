package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CssSelectorByClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();//create webdriver instance
		driver.get("https://demoqa.com/automation-practice-form");
		
		WebElement currentaddress = driver.findElement(By.cssSelector("textarea[class='form-control']")); 
		currentaddress.sendKeys("Chandrapur, ");
		
		WebElement currentaddress1 = driver.findElement(By.cssSelector("textarea.form-control"));
		currentaddress.sendKeys("Gadchiroli, ");
		
		WebElement currentaddress2 = driver.findElement(By.cssSelector("textarea[placeholder='Current Address']"));
		currentaddress2.sendKeys("Bhandara, ");
		
		WebElement currentaddress3 = driver.findElement(By.cssSelector("textarea#currentAddress[placeholder'Current Address']"));
		currentaddress3.sendKeys("Nagpur, ");
		
		WebElement currentaddress4 = driver.findElement(By.cssSelector("textarrea.form-control[placeholder='Current Address']"));
		currentaddress4.sendKeys("Gondia, ");
		
		WebElement currentaddress5 = driver.findElement(By.cssSelector("div>textarea[placeholder='Current Adddress']"));
		currentaddress5.sendKeys("Yavatmal");
	}

}

package first_practical;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise8 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///G:/imp/Flight_Reservation/flight_reservation.html");

		//Switching to Frame1 using index
		driver.switchTo().frame(0);
		
		WebElement frame1_heading1=driver.findElement(By.id("heading1"));
		System.out.println("Frame1 Heading: "+frame1_heading1.getText());
		
		driver.switchTo().defaultContent();
		System.out.println("Title of main window: "+driver.getTitle());
		System.out.println("Switched to main window");
		
		//Switching to frame 2
		driver.switchTo().frame("IF2");
		System.out.println("This is ifrmae 2");

		WebElement frame2_heading1=driver.findElement(By.id("heading2"));
		System.out.println("Frame2 Heading: "+frame2_heading1.getText());
		
		//Switching to sub frmae
		driver.switchTo().frame(0);
		System.out.println("Switched to sub frame inside frame 2 ");
		
		WebElement frame3_heading1=driver.findElement(By.id("heading3"));
		System.out.println("Child Frame Heading: "+frame3_heading1.getText());
		
		driver.switchTo().defaultContent();
		System.out.println("Title of main window: "+driver.getTitle()); 
	}
}


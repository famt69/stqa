package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/HTML%20file%20for%20testing/DragAndDrop.html");
		
		WebElement dragme = driver.findElement(By.id("draggable"));
		
		WebElement dropHere = driver.findElement(By.id("droppable"));
		
		
		Actions builder =new Actions(driver);
		
		
		
				
		
		
		
	}

}

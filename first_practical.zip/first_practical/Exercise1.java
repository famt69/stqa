package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		
		WebElement firstName=driver.findElement(By.cssSelector("input[id='firstName']"));
		firstName.sendKeys("Bob");
		
		WebElement lastName=driver.findElement(By.cssSelector("input[id='lastName']"));
		lastName.sendKeys("Messi");
		
		WebElement mail=driver.findElement(By.cssSelector("input[id='userEmail']"));
		mail.sendKeys("bobmessi@gmail.com");
		
		WebElement gender=driver.findElement(By.cssSelector("label[for='gender-radio-2']"));
		gender.click();
		
		WebElement mob=driver.findElement(By.cssSelector("div>input[id='userNumber']"));
		mob.sendKeys("9764886488");
		
		WebElement sbject=driver.findElement(By.cssSelector("input[id='subjectsInput']"));
		sbject.sendKeys("Software Testing");
		
		WebElement hobby=driver.findElement(By.cssSelector("label[for='hobbies-checkbox-3']"));
		hobby.click();
		
       WebElement uploadElement = driver.findElement(By.id("uploadPicture"));
       uploadElement.sendKeys("C:\\Users\\student\\Downloads\bob.jpg");
		
		WebElement currentAddress=driver.findElement(By.cssSelector("textarea[class='form-control']"));
		currentAddress.sendKeys("Philippines");
		

	}

}

package first_practical;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class HandlindAlert {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/Flight_Reservation/train_reservation.html");
		
		//Handling Simple Alert
		WebElement trainlink = driver.findElement(By.linkText("Trains"));
		trainlink.click();
		
		Alert SimpleAlert = driver.switchTo().alert();
		Thread.sleep(2000);
		String alertText1 = SimpleAlert.getText();
		System.out.println("Simple Alert is" + alertText1);
		SimpleAlert.accept();
		
		Thread.sleep(2000);
		
		
		//Handling Prompt Alert
		WebElement confirm_btn  = driver.findElement(By.cssSelector("input[value='Confirm Details']"));
		confirm_btn.click();
		
		Alert promptAlert = driver.switchTo().alert();
		promptAlert.sendKeys("5");
		Thread.sleep(2000);
		promptAlert.accept();
		
		Thread.sleep(2000);
		
		//Handling Confirmation Alert 
		WebElement book_btn = driver.findElement(By.cssSelector("input[value='Book Tickets']"));
		book_btn.click();
		
		Alert confirmAlert=driver.switchTo().alert();
		System.out.println("Confirmation Alert Is " +confirmAlert.getText());
		Thread.sleep(2000);
		confirmAlert.dismiss();
		
		Thread.sleep(2000);
		
		
		
	}

}

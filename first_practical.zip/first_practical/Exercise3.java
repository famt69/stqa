package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise3 {

public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
	WebDriver driver=new FirefoxDriver();
	driver.get("https://demo.guru99.com/test/login.html");
	
	WebElement email=driver.findElement(By.cssSelector("input[name='email']"));
	email.sendKeys("bob@gmail.com");
	
	WebElement pass=driver.findElement(By.cssSelector("input[id='passwd']"));
	pass.sendKeys("9561");
	
	WebElement button=driver.findElement(By.name("SubmitLogin"));
	button.click();
	
}

}

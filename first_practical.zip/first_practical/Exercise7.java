package first_practical;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise7 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.google.co.in/");
		
		String title = driver.getTitle();
		System.out.println("Title of page: "+title);
		System.out.println("Length of title: "+title.length());
		
		String currentUrl = driver.getCurrentUrl();
		System.out.println("Url of page: "+currentUrl);
		
		String pageSource = driver.getPageSource();
		System.out.println("Page length: "+pageSource.length());
		
		driver.quit();

	}
}


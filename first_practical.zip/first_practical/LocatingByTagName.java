package first_practical;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingByTagName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.guru99.com/test/newtours/");
		
		List <WebElement> list=driver.findElements(By.tagName("input"));//local multiple elements having input tag
		
		for(int i=0;i<list.size();i++)//iterate through list 
			{
			System.out.println(list.get(i).getAttribute("name"));//print value of name attribute
			
		}
		list.get(1).sendKeys("abc@gmail.com");
	}
	}

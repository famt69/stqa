package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class KeyInteractions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://demo.guru99.com/test/login.html");
		
		WebElement emailAddress=  driver.findElement(By.id("email"));
		
		Actions builder = new Actions(driver);
		builder.keyDown(emailAddress, Keys.SHIFT).sendKeys("harshad").perform();
		builder.keyUp(emailAddress, Keys.SHIFT);
		
		builder.sendKeys("sorte");
		
		
	}

}

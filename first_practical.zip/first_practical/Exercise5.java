package first_practical;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise5 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demo.guru99.com/test/facebook.html");
		
		List<WebElement> inputs=driver.findElements(By.tagName("input"));
		inputs.get(1).sendKeys("bob@gmail.com");
		inputs.get(2).sendKeys("9561");
		
	}

}

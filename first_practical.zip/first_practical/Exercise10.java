package first_practical;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise10 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///G:/imp/Flight_Reservation/flight_reservation.html");
		
		String mainWindow=driver.getWindowHandle();//retrieve the unique id of flight reservation window
	    System.out.println("Main Window Handle :"+mainWindow);
		System.out.println("Title of main window is: "+driver.getTitle());
		
		WebElement hotel_link=driver.findElement(By.linkText("Hotels"));
		hotel_link.click();
		
		Set<String> handles=driver.getWindowHandles();
		for(String windowHandle:handles)
		{
			if(!windowHandle.equals(mainWindow))
			{
				driver.switchTo().window(windowHandle);
				System.out.println("Title of child window is "+driver.getTitle());
				WebElement heading1=driver.findElement(By.id("sampleHeading"));
				System.out.println("Heading inside child window is "+heading1.getText());
				Thread.sleep(4000);
				driver.close();
			}
		}
		driver.switchTo().window(mainWindow);
		System.out.println("Title of main window: "+driver.getTitle());

	}

}


package first_practical;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingByClasssName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();//create webdriver instance
		driver.get("https://demo.guru99.com/test/facebook.html");
		
		List<WebElement> txtbox=driver.findElements(By.className("inputtext"));
		System.out.println(txtbox.size());
		
		for(int i=0;i<txtbox.size();i++) {
			System.out.println(txtbox.get(i).getAttribute("name"));
		}
		txtbox.get(0).sendKeys("abc@gmail.com");
		txtbox.get(1).sendKeys("abcdefghijk");
	}

}

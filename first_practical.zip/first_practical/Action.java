package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Action {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demo.guru99.com/test/selenium-xpath.html");

		WebElement userid=driver.findElement(By.name("uid"));
		System.out.println(userid.getAttribute("name"));

		WebElement uidmsg=driver.findElement(By.xpath("//label[@id='message23']"));
		System.out.println(uidmsg.getAttribute("id"));

		userid.sendKeys("Harshad");
		Thread.sleep(5000);
		userid.clear();

		WebElement login =driver.findElement(By.name("btnLogin"));
		//login.submit();

		System.out.println(userid.getLocation());
		System.out.println(userid.getSize());
		System.out.println(uidmsg.getText());
		System.out.println(userid.getCssValue("background-color"));
		System.out.println(userid.getCssValue("border-color"));
		System.out.println(userid.getTagName());
		System.out.println(userid.isDisplayed());
		System.out.println(userid.isEnabled());
		
	}

}


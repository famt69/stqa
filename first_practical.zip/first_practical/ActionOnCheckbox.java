package first_practical;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class ActionOnCheckbox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://only-testing-blog.blogspot.com/2013/09/test.html");
		
		WebElement lastname = driver.findElement(By.name("lname"));
				
		WebElement bike =driver.findElement(By.cssSelector("input[value='Bike']"));
		WebElement car =driver.findElement(By.cssSelector("input[value='Car']"));
		WebElement boat =driver.findElement(By.cssSelector("input[value='Boat']"));
		
		bike.click();
		car.click();
		
		System.out.println(boat.isSelected());
		System.out.println(car.isSelected());
		
		if(lastname.isEnabled())
		{
			System.out.println("LastName Text box is enabled");
		}else {
			System.out.println("Last Name Text  box is not enabled");
		}
		
		Select cartype = new Select(driver.findElement(By.tagName("select")));
		cartype.selectByValue("UK");
		Thread.sleep(2000);
		
		cartype.selectByIndex(0);
		
		if(cartype.isMultiple()) 
		{
			List<WebElement> selected_items=cartype.getAllSelectedOptions();
			for(int i=0;i<selected_items.size();i++) 
			{
				System.out.println(selected_items.get(i).getText());
				
			}	
		}
		else 
		{
			System.out.println("Multiple selection is no allowed");
		}
		
	}

}

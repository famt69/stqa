package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Exercise2 {

public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
	WebDriver driver=new FirefoxDriver();
	driver.get("https://demo.guru99.com/test/newtours/");
	
	WebElement user=driver.findElement(By.cssSelector("input[name='userName']"));
	user.sendKeys("bob@gmail.com");
	
	WebElement pass=driver.findElement(By.cssSelector("input[name='password']"));
	pass.sendKeys("9561");
	
	WebElement register_link=driver.findElement(By.linkText("REGISTER"));
	System.out.println(register_link.getText());
	
	WebElement signon_link=driver.findElement(By.linkText("SIGN-ON"));
	System.out.println(signon_link.getText());
	
	WebElement contact_link=driver.findElement(By.linkText("CONTACT"));
	System.out.println(contact_link.getText());
	
	WebElement support_link=driver.findElement(By.linkText("SUPPORT"));
	System.out.println(support_link.getText());
	
	

}

}

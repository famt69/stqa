package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class ClickAndHoldAtCurrentPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/HTML%20file%20for%20testing/Sortable.html");
		
		//get the location of title 3 and move the cursor to tile 3
		WebElement three = driver.findElement(By.name("three"));
		
		//X and Y coordinate of tile 3
		System.out.println("X coordinate of tile 3: "+three.getLocation().x + " Y coodinate tile 3:  "+three.getLocation().y);
		
		Actions builder = new Actions(driver);
		//move to tile 3
		builder.moveByOffset(three.getLocation().x+1,three.getLocation().y+1);
		
		//click and hold tile 3
		builder.clickAndHold();
		
		//locate tile 2
		WebElement two = driver.findElement(By.name("two"));
		
		//x and y coordinate of tile 2
		System.out.println("X coordinate of tile 2: "+two.getLocation().x + " Y coodinate tile 2:  "+two.getLocation().y);
		
		builder.moveByOffset(115,0);
		
		builder.perform();
		
		
		
	}

}

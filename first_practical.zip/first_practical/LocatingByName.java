package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingByName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get(" http://demo.guru99.com/test/login.html");
		
		WebElement emailBox = driver.findElement(By.id("email"));
		emailBox.sendKeys("abc@gmail.com");
		
		WebElement passwdBox = driver.findElement(By.name("passwd"));
		passwdBox.sendKeys("abcdefghlkji");
		
		WebElement SignInButton =driver.findElement(By.name("SubmitLogin"));
		SignInButton.submit();

	}

}

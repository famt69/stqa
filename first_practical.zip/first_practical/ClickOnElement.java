package first_practical;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class ClickOnElement {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///E:/HTML%20file%20for%20testing/Selectable.html");
		
		WebElement two = driver.findElement(By.name("two"));
		WebElement five = driver.findElement(By.name("five"));
		WebElement ten = driver.findElement(By.name("ten"));
		
		Actions builder = new Actions(driver);
		
		//builder.click(two);
		//builder.perform();
		
		//Thread.sleep(2000);
		
		//builder.click(five);
		//builder.perform();
		//Thread.sleep(2000);
		
		//builder.click(ten);
		//builder.perform();
		
		builder.click(two).click(five).click(ten);//composite action
		builder.perform();
		
		
		
	}

}

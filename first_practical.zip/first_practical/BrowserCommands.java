package first_practical;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserCommands {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.google.com/");
		
		String page_title = driver.getTitle();
		System.out.println("Page Title is "+ page_title);
		
		driver.navigate().to("https://timesofindia.indiatimes.com/city/indore/all-you-need-to-know-about-ujjains-mahakal-lok-corridor/articleshow/94776634.cms");
		
		String current_url = driver.getCurrentUrl();
		System.out.println("Current URL is "+current_url);
		
		String page_source = driver.getPageSource();
		System.out.println("Page Source is "+page_source);	
		
		driver.quit();
		
		
	}

}
